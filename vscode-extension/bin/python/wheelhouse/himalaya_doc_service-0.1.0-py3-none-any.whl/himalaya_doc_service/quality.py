"""Quality assessment for generated documents.

Evaluates structural completeness, content density, and format-specific
quality metrics. Returns a QualityReport compatible with the Rust
file-generate crate's format.
"""

from __future__ import annotations

import os
import re
from typing import Any

from .spec import BlockType, DocumentSpec, DocumentType, SpecBlock


class QualityStatus:
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    BLOCKER = "blocker"


def assess_document(format: str, spec: DocumentSpec, file_path: str | None = None, **extra) -> dict[str, Any]:
    """Run all quality checks and return a QualityReport dict.

    The returned dict is compatible with the Rust GenerateReport.quality format:
        {"block_count", "table_count", "formula_count", "chart_count",
         "image_count", "check_count", "warning_count", "checks": [...], "warnings": [...]}
    """
    all_blocks = list(_iter_blocks(spec.blocks))
    report = {
        "block_count": len(all_blocks),
        "table_count": 0,
        "formula_count": 0,
        "formula_image_count": 0,
        "chart_count": 0,
        "image_count": 0,
        "source_ref_count": 0,
        "speaker_note_count": 0,
        "check_count": 0,
        "warning_count": 0,
        "failure_count": 0,
        "blocker_count": 0,
        "quality_level": "",
        "quality_score": 100,
        "editable_formula_count": 0,
        "rendered_formula_count": 0,
        "latex_only_formula_count": 0,
        "checks": [],
        "warnings": [],
        "failures": [],
        "blockers": [],
    }

    _check = _make_checker(report)

    # Content presence
    has_content = bool(spec.blocks) or bool(spec.sheets)
    _check("content.present" if has_content else "content.empty",
           "Document has content blocks or sheets." if has_content else "Document has no blocks or sheets.",
           QualityStatus.WARN if not has_content else QualityStatus.PASS)

    # Per-block checks
    placeholder_hits: list[str] = []
    slide_titles: list[str] = []
    source_ref_count = len(spec.source_documents)
    speaker_note_count = 0

    for block in all_blocks:
        bt = block.type
        source_ref_count += len(block.source_refs or [])
        if block.speaker_notes:
            speaker_note_count += 1

        if block.type == BlockType.HEADING and (block.level or 1) == 1 and block.text:
            slide_titles.append(block.text)

        block_text = _block_text(block)
        if _looks_like_placeholder(block_text):
            placeholder_hits.append(_shorten(block_text))

        if bt == BlockType.TABLE:
            report["table_count"] += 1
            headers_len = len(block.headers or [])
            rows_len = len(block.rows or [])
            if headers_len == 0 and rows_len == 0:
                _check("table.empty", "A table has no headers or rows.", QualityStatus.WARN)
            elif rows_len > 0:
                for i, row in enumerate(block.rows or []):
                    if len(row) != headers_len:
                        _check("table.irregular", f"Table row {i} has {len(row)} columns, expected {headers_len}.", QualityStatus.WARN)

        elif bt == BlockType.FORMULA:
            report["formula_count"] += 1
            report["latex_only_formula_count"] += 1
            if not block.latex:
                _check("formula.empty", "A formula block has no latex content.", QualityStatus.WARN)

        elif bt == BlockType.CHART:
            report["chart_count"] += 1
            labels_len = len(block.labels or [])
            if labels_len == 0 and not block.series:
                _check("chart.empty", "A chart has no labels or series.", QualityStatus.WARN)
            if block.series and labels_len > 0:
                for s in block.series:
                    if len(s.values) != labels_len:
                        _check("chart.irregular", f"Chart series '{s.name}' has {len(s.values)} values but {labels_len} labels.", QualityStatus.WARN)

        elif bt == BlockType.IMAGE:
            report["image_count"] += 1
            if (block.asset_role or "").lower() in ("formula", "formula_image", "formula_candidate"):
                report["formula_image_count"] += 1
            if not block.path:
                _check("image.nopath", "An image block has no path.", QualityStatus.WARN)
            elif not _path_exists(block.path):
                _check("image.missing", f"Image path does not exist: {block.path}", QualityStatus.WARN)
            if block.source_path and block.crop_box and len(block.crop_box) not in (4,):
                _check("image.crop.invalid", "An image crop_box must contain four numbers.", QualityStatus.WARN)

    report["source_ref_count"] = source_ref_count
    report["speaker_note_count"] = speaker_note_count
    report["extracted_asset_count"] = sum(
        1 for block in all_blocks
        if block.type == BlockType.IMAGE and (block.source_path or block.crop_box or block.asset_role)
    )

    if placeholder_hits:
        _check(
            "content.placeholders",
            f"Placeholder-like text remains in generated content: {', '.join(placeholder_hits[:5])}.",
            QualityStatus.WARN,
        )

    if len(slide_titles) != len(set(slide_titles)):
        _check("pptx.duplicate_titles", "PPTX contains duplicate slide titles.", QualityStatus.WARN)

    # Sheet checks (XLSX)
    for sheet in spec.sheets:
        if not sheet.rows and not sheet.formulas:
            _check("sheet.empty", f"Sheet '{sheet.name}' has no rows or formulas.", QualityStatus.WARN)

    _check_generation_contract(format, spec, report, _check, slide_titles, extra)

    # Format-specific notes
    if format in ("pptx",):
        slide_count = len([b for b in spec.blocks if b.type == BlockType.HEADING and (b.level or 1) == 1])
        if slide_count == 0:
            slide_count = 1  # implicit slide from non-heading content
        if slide_count > 80:
            _check("pptx.too_many_slides", f"PPTX has {slide_count} slides (max recommended: 80).", QualityStatus.WARN)
        # extra key for convenience
        report["slide_count"] = extra.get("slide_count", slide_count)

    if format in ("xlsx",):
        sheet_count = len(spec.sheets)
        if sheet_count == 0 and report["table_count"] == 0:
            _check("xlsx.empty", "XLSX has no sheets or tables.", QualityStatus.WARN)

    # Format warning
    formula_evidence_count = report["formula_count"] + report.get("formula_image_count", 0)

    if format in ("docx", "pptx", "pdf"):
        if report["formula_count"] > 0:
            report["rendered_formula_count"] = report["formula_count"]
            report["latex_only_formula_count"] = 0
            _check("formula.rendering", f"Formulas in {format.upper()} are rendered as high-resolution images.", QualityStatus.PASS)
        if report.get("formula_image_count", 0) > 0:
            _check("formula.image_evidence", f"{report['formula_image_count']} source formula image(s) are embedded.", QualityStatus.PASS)
        if report["chart_count"] > 0:
            _check("chart.rendering", f"Charts in {format.upper()} are rendered as embedded chart objects or images.", QualityStatus.PASS)

    contract = spec.generation_contract
    if contract and contract.minimum_quality_score is not None:
        projected_score = max(0, min(100, 100 - (report["warning_count"] * 3 + report["failure_count"] * 18 + report["blocker_count"] * 30)))
        if projected_score < contract.minimum_quality_score:
            _contract_check(_check, contract, "quality.score_below_minimum", f"Projected quality score {projected_score} is below the required minimum {contract.minimum_quality_score}.")

    _finish_report(report)
    return report


PLACEHOLDER_RE = re.compile(
    r"(\bTBD\b|\bTODO\b|\bXXX\b|\bunknown\b|\blorem ipsum\b|\binsert\b|"
    r"\[.*?(title|paper|author|figure|table|name).*?\]|Figure\s+X|Table\s+X)",
    re.IGNORECASE,
)


def _iter_blocks(blocks: list[SpecBlock]):
    for block in blocks:
        yield block
        if block.left:
            yield from _iter_blocks(block.left)
        if block.right:
            yield from _iter_blocks(block.right)


def _block_text(block: SpecBlock) -> str:
    parts: list[str] = []
    for value in (
        block.text,
        block.caption,
        block.title,
        block.display,
        block.latex,
        block.code,
        block.key_message,
        block.speaker_notes,
    ):
        if value:
            parts.append(str(value))
    if block.items:
        parts.extend(str(i) for i in block.items)
    if block.headers:
        parts.extend(str(h) for h in block.headers)
    if block.rows:
        for row in block.rows:
            parts.extend(str(cell) for cell in row)
    return " ".join(parts)


def _looks_like_placeholder(text: str) -> bool:
    return bool(text and PLACEHOLDER_RE.search(text))


def _shorten(text: str, limit: int = 80) -> str:
    collapsed = re.sub(r"\s+", " ", text).strip()
    return collapsed if len(collapsed) <= limit else collapsed[: limit - 1] + "..."


def _path_exists(path: str) -> bool:
    return os.path.exists(path) or os.path.exists(os.path.join(os.getcwd(), path))


def _check_generation_contract(
    format: str,
    spec: DocumentSpec,
    report: dict[str, Any],
    check,
    slide_titles: list[str],
    extra: dict[str, Any],
) -> None:
    contract = spec.generation_contract
    doc_type = spec.document_type
    is_academic = doc_type in (
        DocumentType.ACADEMIC_PAPER,
        DocumentType.DEGREE_DEFENSE,
        DocumentType.ACADEMIC_TALK,
    )

    if spec.source_documents:
        check("sources.present", f"{len(spec.source_documents)} source document reference(s) recorded.", QualityStatus.PASS)
    elif is_academic or (contract and contract.strict_source_grounding):
        _contract_check(check, contract, "sources.missing", "Academic or grounded document has no source_documents recorded.")

    if contract and contract.strict_source_grounding and report.get("source_ref_count", 0) == 0:
        _contract_check(check, contract, "sources.block_refs_missing", "Strict source grounding is enabled but no block-level source_refs were recorded.")

    if contract and contract.required_assets:
        req = contract.required_assets
        if report["image_count"] < req.figures:
            _contract_check(check, contract, "assets.figures_missing", f"Expected at least {req.figures} figure image(s), found {report['image_count']}.")
        if report["table_count"] < req.tables:
            _contract_check(check, contract, "assets.tables_missing", f"Expected at least {req.tables} table(s), found {report['table_count']}.")
        formula_evidence_count = report["formula_count"] + report.get("formula_image_count", 0)
        if formula_evidence_count < req.formulas:
            _contract_check(check, contract, "assets.formulas_missing", f"Expected at least {req.formulas} formula evidence item(s), found {formula_evidence_count}.")
        if report["chart_count"] < req.charts:
            _contract_check(check, contract, "assets.charts_missing", f"Expected at least {req.charts} chart(s), found {report['chart_count']}.")
        if req.require_source_refs and report.get("source_ref_count", 0) == 0:
            _contract_check(check, contract, "assets.source_refs_missing", "Required assets need source references, but none were recorded.")
        if req.require_extracted_assets and report.get("extracted_asset_count", 0) == 0:
            _contract_check(check, contract, "assets.extracted_missing", "Required source-extracted assets were requested, but no image block records source_path, crop_box, or asset_role.")

    if contract and contract.required_sections:
        joined_titles = " ".join(slide_titles).lower()
        missing = [s for s in contract.required_sections if s.lower() not in joined_titles]
        if missing:
            _contract_check(check, contract, "sections.missing", f"Missing required section title(s): {', '.join(missing)}.")

    expected_slide_count = contract.expected_slide_count if contract else None
    actual_slide_count = int(extra.get("slide_count") or len(slide_titles) or 0)
    if format == "pptx" and expected_slide_count and actual_slide_count:
        lower = max(1, int(expected_slide_count * 0.75))
        upper = max(expected_slide_count + 2, int(expected_slide_count * 1.35))
        if actual_slide_count < lower or actual_slide_count > upper:
            _contract_check(check, contract, "pptx.slide_count_contract", f"PPTX has {actual_slide_count} slide(s), outside expected range for {expected_slide_count}.")

    if format == "pptx" and doc_type == DocumentType.DEGREE_DEFENSE:
        if actual_slide_count and actual_slide_count < 8 and (not expected_slide_count or expected_slide_count >= 8):
            check("defense.too_short", "Degree defense deck is unusually short; expected a complete research narrative.", QualityStatus.WARN)
        formula_evidence_count = report["formula_count"] + report.get("formula_image_count", 0)
        if formula_evidence_count == 0:
            if spec.source_documents or (contract and contract.strict_source_grounding):
                check("defense.no_formulas", "Degree defense deck has no formulas recorded; STEM thesis defenses should include key equations or formula evidence from the source.", QualityStatus.FAIL)
            else:
                check("defense.no_formulas", "Degree defense deck has no formulas recorded.", QualityStatus.WARN)
        if report["table_count"] == 0 and report["chart_count"] == 0 and report["image_count"] == 0:
            check("defense.no_visual_evidence", "Degree defense deck has no table/chart/image evidence blocks.", QualityStatus.WARN)
        if report["image_count"] == 0:
            if spec.source_documents:
                check("defense.no_source_figures", "Degree defense deck has no image blocks; important figures from the source PDF are missing.", QualityStatus.FAIL)
            elif contract and (contract.strict_source_grounding or (contract.required_assets and (contract.required_assets.figures > 0 or contract.required_assets.require_extracted_assets))):
                _contract_check(check, contract, "defense.no_source_figures", "Degree defense deck has no image blocks; important figures from the source PDF may be missing.")
            else:
                check("defense.no_source_figures", "Degree defense deck has no image blocks; important figures from the source PDF may be missing.", QualityStatus.WARN)
        elif (spec.source_documents or (contract and contract.strict_source_grounding)) and report.get("extracted_asset_count", 0) == 0:
            check("defense.no_extracted_source_assets", "Degree defense deck has image blocks, but none are traced to extracted source assets (source_path, crop_box, or asset_role).", QualityStatus.FAIL)

    if contract and contract.require_speaker_notes and report.get("speaker_note_count", 0) == 0:
        _contract_check(check, contract, "speaker_notes.missing", "Generation contract requires speaker notes, but none were recorded.")

    if (
        contract
        and contract.require_editable_formulas
        and report["formula_count"] > 0
        and format in ("pptx", "docx", "pdf")
    ):
        _contract_check(check, contract, "formula.editable_native_unavailable", "Formula blocks preserve LaTeX/source metadata, but this backend renders formulas as images rather than native Office Math equation objects.")


def _contract_check(check, contract, id: str, message: str) -> None:
    if contract and contract.fail_on_contract_violation and not contract.allow_degraded_output:
        check(id, message, QualityStatus.FAIL)
    else:
        check(id, message, QualityStatus.WARN)


def _finish_report(report: dict[str, Any]) -> None:
    penalty = report.get("warning_count", 0) * 3 + report.get("failure_count", 0) * 18 + report.get("blocker_count", 0) * 30
    report["quality_score"] = max(0, min(100, 100 - penalty))
    if report.get("blocker_count", 0):
        report["quality_level"] = "blocked"
    elif report.get("failure_count", 0):
        report["quality_level"] = "failed"
    elif report.get("warning_count", 0):
        report["quality_level"] = "degraded"
    else:
        report["quality_level"] = "final"


def _make_checker(report: dict[str, Any]):
    """Return a closure that appends a check and increments counters."""
    def check(id: str, message: str, status: str):
        report["check_count"] += 1
        if status == QualityStatus.WARN:
            report["warning_count"] += 1
            report["warnings"].append(f"[{id}] {message}")
        elif status == QualityStatus.FAIL:
            report["failure_count"] += 1
            report["failures"].append(f"[{id}] {message}")
        elif status == QualityStatus.BLOCKER:
            report["blocker_count"] += 1
            report["blockers"].append(f"[{id}] {message}")
        report["checks"].append({"id": id, "status": status, "message": message})
    return check
